<template>
  <div id="container">
    <header id="encabezado">
      <h2>TALONARIO</h2>
    </header>
    <div v-if="showModal" class="modal-backdrop">
      <div class="modal-config">
        <div class="modal-header">
          <span>CONFIGURA TU TALONARIO</span>
          <button class="close-btn" @click="showModal = false">&times;</button>
        </div>
        <form @submit.prevent="guardarTalonario">
          <input
            v-model="premio"
            type="text"
            placeholder="Ingrese el premio de la rifa"
          />
          <input
            v-model="valor"
            type="number"
            placeholder="Ingrese valor de la boleta"
          />
          <select v-model="loteria">
            <option value="" disabled>Seleccione la loteria</option>
            <option>Cruz Roja</option>
            <option>La Perla</option>
            <option>Santander</option>
            <option>Baloto</option>
          </select>
          <select v-model="rango">
            <option value="" disabled>Cantidad de boletas</option>
            <option>0-99</option>
            <option>0-999</option>
          </select>
          <input
            v-model="fecha"
            type="date"
          />
          <button type="submit" class="guardar-btn">Guardar</button>
        </form>
      </div>
    </div>
    <div class="info">
     <div class="info-talonario-wrapper">
      <div class="info-talonario">
        <h3 class="titulo-info">Información del Talonario</h3>
        <div v-if="premio || valor || loteria || rango || fecha">
          <p v-if="premio"><b>Premio:</b> {{ premio }}</p>
          <p v-if="valor"><b>Valor:</b> {{ valor }}</p>
          <p v-if="loteria"><b>Lotería:</b> {{ loteria }}</p>
          <p v-if="rango"><b>Rango:</b> {{ rango }}</p>
          <p v-if="fecha"><b>Fecha:</b> {{ fecha }}</p>
        </div>
      </div>
    </div>
    <div class="cuerpo-info">
      <h3 class="titulo-info">Acciones</h3>
      <div class="cuerpo-acciones">

      </div>
    </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const Swal = window.Swal

const showModal = ref(true)
const premio = ref('')
const valor = ref('')
const loteria = ref('')
const rango = ref('')
const fecha = ref('')

function showSwal(options) {
  Swal.fire({
    ...options,
    timer: 10000,
    timerProgressBar: true,
    allowOutsideClick: false,
    allowEscapeKey: false,
    didOpen: () => {
      const swalPopup = document.querySelector('.swal2-popup')
      const swalBackdrop = document.querySelector('.swal2-backdrop')
      if (swalPopup) swalPopup.style.zIndex = 0
      if (swalBackdrop) swalBackdrop.style.zIndex = 0
    }
  })
}

function guardarTalonario() {
  if (!premio.value) {
    showSwal({
      icon: "error",
      title: "Oops",
      text: "El valor del premio no puede estar vacío."
    })
    return
  }
  if (isNaN(Number(premio.value))) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "El valor del premio debe ser numérico."
    })
    return
  }
  if (Number(premio.value) <= 0) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "El valor del premio debe ser mayor a cero."
    })
    return
  }
  if (!valor.value) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "El valor de la boleta no puede estar vacío."
    })
    return
  }
  if (isNaN(Number(valor.value)) || Number(valor.value) <= 0) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "El valor de la boleta debe ser numérico y mayor a cero."
    })
    return
  }
  if (Number(valor.value) > Number(premio.value)) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "El valor de la boleta no puede ser superior al premio."
    })
    return
  }
  if (!loteria.value) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "Seleccione la lotería que quieras jugar."
    })
    return
  }
  if (!rango.value) {
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "Seleccione la cantidad de boletas."
    })
    return
  }
  if (!fecha.value) { 
    showSwal({
      icon: "error",
      title: "Oops...",
      text: "Seleccione la fecha del sorteo."
    })
    return
  }

  
  Swal.fire({
    title: "Ta melo!",
    icon: "success",
    draggable: true
  })
  showModal.value = false
}

</script>

<style scoped>
#encabezado {
  background-color: rgb(1, 75, 174);
  height: 80px;
  position: fixed;
  width: 100%;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 1px 1px #0006;
}

h2 {
  color: #fff;
  font-size: 45px;
}

.contenido {
  margin-top: 100px;
}

.container.text-center .row .col {
  background-color:rgba(185,185,185,255);
  margin:20px;
}

/* Modal estilos */
.modal-backdrop {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}
.modal-config {
  background: #fff;
  border-radius: 12px;
  min-width: 340px;
  box-shadow: 0 2px 8px #0006;
  padding: 0 24px 24px 24px;
  border: 2px solid #888;
}
.modal-header {
  background: #014bae;
  color: #fff;
  font-weight: bold;
  font-size: 18px;
  border-radius: 10px 10px 0 0;
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: -24px -24px 20px -24px;
}
.close-btn {
  background: none;
  border: none;
  color: #fff;
  font-size: 26px;
  cursor: pointer;
  line-height: 1;
}
.modal-config form {
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.modal-config input,
.modal-config select {
  padding: 10px;
  border: 1px solid #bbb;
  border-radius: 5px;
  font-size: 16px;
}
.guardar-btn {
  background: #014bae;
  color: #fff;
  border: none;
  border-radius: 6px;
  padding: 12px 0;
  font-size: 18px;
  margin-top: 10px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.2s;
}
.guardar-btn:hover {
  background: #003e8a;
}

.info{
     margin-top: 120px;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    justify-items: center;
    gap: 10px
}
.info-talonario-wrapper{
  display:flex;
  justify-content: left;
  align-items: flex-start;
  min-height: 80vh;
  margin-top: 100px;
}

.info-talonario {
background: #e7e7e7;
    width: 380px;
    height: 450px;
    border-radius: 20px;
    padding: 15px
}
.info-talonario h3 {
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 20px;
}

.info-talonario p {
  font-size: 1.2rem;
  margin: 10px 0;
}
.titulo-info {
    text-align: center;
}
h3 {
    font-weight: bolder;
    text-align: center;
}
.cont-acciones {
    background: #e7e7e7;
    width: 380px;
    height: 450px;
    border-radius: 20px;
    padding: 15px;
}

.cuerpo-acciones {
    background: #fff;
    height: 355px;
    border-radius: 20px;
    margin-top: 9px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}
</style>